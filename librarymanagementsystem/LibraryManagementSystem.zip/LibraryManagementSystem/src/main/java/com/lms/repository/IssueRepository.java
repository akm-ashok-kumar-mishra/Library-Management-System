package com.lms.repository;

import com.lms.entity.Issue;
import com.lms.entity.Issue.IssueStatus;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Long> {

    // 📘 Issues by student
    List<Issue> findByStudent_Id(Long studentId);

    // 📘 Issues by book
    List<Issue> findByBook_Id(Long bookId);

    // 📊 Issues by status
    List<Issue> findByStatus(IssueStatus status);

    // 🔥 Active issues for a student
    @Query("SELECT i FROM Issue i WHERE i.student.id = :studentId AND i.status = 'ISSUED'")
    List<Issue> findActiveIssuesByStudent(@Param("studentId") Long studentId);

    // 🔥 Active issues for a book
    @Query("SELECT i FROM Issue i WHERE i.book.id = :bookId AND i.status = 'ISSUED'")
    List<Issue> findActiveIssuesByBook(@Param("bookId") Long bookId);

    // 🔢 Count active issues for student
    @Query("SELECT COUNT(i) FROM Issue i WHERE i.student.id = :studentId AND i.status = 'ISSUED'")
    long countActiveIssuesByStudent(@Param("studentId") Long studentId);

    // ⚠ Overdue issues
    @Query("SELECT i FROM Issue i WHERE i.status = :status AND i.dueDate < :today")
    List<Issue> findOverdueIssues(@Param("status") IssueStatus status,
                                 @Param("today") LocalDate today);

    // 📅 Issues between dates
    @Query("SELECT i FROM Issue i WHERE i.issueDate BETWEEN :start AND :end")
    List<Issue> findIssuesBetweenDates(@Param("start") LocalDate start,
                                      @Param("end") LocalDate end);
}