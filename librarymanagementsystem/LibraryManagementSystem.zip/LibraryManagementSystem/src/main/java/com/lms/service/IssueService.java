package com.lms.service;

import com.lms.exception.ResourceNotFoundException;
import com.lms.entity.*;
import com.lms.entity.Issue.IssueStatus;
import com.lms.repository.*;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@Transactional
public class IssueService {

    private final IssueRepository issueRepo;
    private final BookService bookService;
    private final StudentService studentService;

    private static final double FINE_PER_DAY = 5.0;

    public IssueService(IssueRepository issueRepo,
                        BookService bookService,
                        StudentService studentService) {
        this.issueRepo = issueRepo;
        this.bookService = bookService;
        this.studentService = studentService;
    }

    public List<Issue> getAllIssues() {
        return issueRepo.findAll();
    }

    public Issue getIssueById(Long id) {
        return issueRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Issue not found"));
    }

    // 🔥 ISSUE BOOK
    public void issueBook(Long bookId, Long studentId) {

        Book book = bookService.getBookById(bookId);
        Student student = studentService.getStudentById(studentId);

        if (!book.isAvailable()) {
            throw new RuntimeException("Book not available");
        }

        if (!studentService.canIssue(studentId)) {
            throw new RuntimeException("Student reached limit (5 books)");
        }

        Issue issue = new Issue();
        issue.setBook(book);
        issue.setStudent(student);
        issue.setIssueDate(LocalDate.now());
        issue.setDueDate(LocalDate.now().plusDays(14));
        issue.setStatus(IssueStatus.ISSUED);

        bookService.decreaseAvailable(bookId);

        issueRepo.save(issue);
    }

    // 🔥 RETURN BOOK + FINE
    public void returnBook(Long issueId) {

        Issue issue = getIssueById(issueId);

        if (issue.getStatus() != IssueStatus.ISSUED) {
            throw new RuntimeException("Book already returned");
        }

        LocalDate today = LocalDate.now();
        issue.setReturnDate(today);

        if (today.isAfter(issue.getDueDate())) {
            long days = ChronoUnit.DAYS.between(issue.getDueDate(), today);

            issue.setFineAmount(days * FINE_PER_DAY);
            issue.setStatus(IssueStatus.OVERDUE);
        } else {
            issue.setFineAmount(0.0);
            issue.setStatus(IssueStatus.RETURNED);
        }

        bookService.increaseAvailable(issue.getBook().getId());

        issueRepo.save(issue);
    }

    // 🔥 OVERDUE LIST
    public List<Issue> getOverdueIssues() {
        return issueRepo.findOverdueIssues(IssueStatus.ISSUED, LocalDate.now());
    }

    public List<Issue> getByStudent(Long studentId) {
        return issueRepo.findByStudent_Id(studentId);
    }

    public List<Issue> getByBook(Long bookId) {
        return issueRepo.findByBook_Id(bookId);
    }
}