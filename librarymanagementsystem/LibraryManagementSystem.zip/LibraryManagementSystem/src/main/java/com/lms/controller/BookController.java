package com.lms.controller;

import com.lms.entity.Book;
import com.lms.service.BookService;

import jakarta.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/books")
public class BookController {

    private final BookService service;

    public BookController(BookService service) {
        this.service = service;
    }

    // 📄 LIST
    @GetMapping
    public String list(Model model,
                       @RequestParam(value = "search", required = false) String keyword) {

        model.addAttribute("books",
                (keyword != null && !keyword.isBlank())
                        ? service.searchBooks(keyword)
                        : service.getAllBooks());

        model.addAttribute("search", keyword);
        return "book-list";
    }

    // ➕ FORM
    @GetMapping("/add")
    public String showForm(Model model) {
        model.addAttribute("book", new Book());
        return "book-add";
    }

    // 💾 SAVE
    @PostMapping("/add")
    public String save(@Valid @ModelAttribute("book") Book book,
                       BindingResult result,
                       Model model,
                       RedirectAttributes ra) {

        if (result.hasErrors()) {
            return "book-add";
        }

        try {
            service.saveBook(book);
            ra.addFlashAttribute("success", "Book added successfully");
            return "redirect:/books";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "book-add";
        }
    }

    // ✏ EDIT FORM
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("book", service.getBookById(id));
        return "book-edit";
    }

    // 🔄 UPDATE
    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id,
                         @Valid @ModelAttribute("book") Book book,
                         BindingResult result,
                         Model model,
                         RedirectAttributes ra) {

        if (result.hasErrors()) return "book-edit";

        try {
            service.updateBook(id, book);
            ra.addFlashAttribute("success", "Book updated");
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "book-edit";
        }

        return "redirect:/books";
    }

    // ❌ DELETE
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id,
                         RedirectAttributes ra) {

        try {
            service.deleteBook(id);
            ra.addFlashAttribute("success", "Book deleted");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/books";
    }
}