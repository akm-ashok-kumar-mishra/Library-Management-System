package com.lms.repository;

import com.lms.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {

    // Find by email
    Optional<Student> findByEmail(String email);

    // Check email exists
    boolean existsByEmail(String email);

    // Find by studentId
    Optional<Student> findByStudentId(String studentId);

    boolean existsByStudentId(String studentId);

    // Search by name
    List<Student> findByNameContainingIgnoreCase(String name);

    // 🔍 Global search
    @Query("SELECT s FROM Student s WHERE " +
            "LOWER(s.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.studentId) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Student> searchStudents(@Param("keyword") String keyword);
}