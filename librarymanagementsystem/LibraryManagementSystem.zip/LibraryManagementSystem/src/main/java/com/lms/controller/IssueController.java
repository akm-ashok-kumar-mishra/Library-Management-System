package com.lms.controller;

import com.lms.service.BookService;
import com.lms.service.IssueService;
import com.lms.service.StudentService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/issues")
public class IssueController {

    private final IssueService issueService;
    private final BookService bookService;
    private final StudentService studentService;

    public IssueController(IssueService issueService,
                           BookService bookService,
                           StudentService studentService) {
        this.issueService = issueService;
        this.bookService = bookService;
        this.studentService = studentService;
    }

    // 📄 LIST
    @GetMapping
    public String list(Model model) {
        model.addAttribute("issues", issueService.getAllIssues());
        return "issue-list";
    }

    // ➕ ISSUE FORM
    @GetMapping("/add")
    public String form(Model model) {
        model.addAttribute("books", bookService.getAvailableBooks());
        model.addAttribute("students", studentService.getAllStudents());
        return "issue-add";
    }

    // 📌 ISSUE BOOK
    @PostMapping("/add")
    public String issue(@RequestParam Long bookId,
                        @RequestParam Long studentId,
                        RedirectAttributes ra) {

        try {
            issueService.issueBook(bookId, studentId);
            ra.addFlashAttribute("success", "Book issued");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/issues";
    }

    // 🔁 RETURN
    @PostMapping("/return/{id}")
    public String returnBook(@PathVariable Long id,
                             RedirectAttributes ra) {

        try {
            issueService.returnBook(id);
            ra.addFlashAttribute("success", "Book returned");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/issues";
    }
}