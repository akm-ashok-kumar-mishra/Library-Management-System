package com.lms.service;

import com.lms.exception.ResourceNotFoundException;
import com.lms.entity.Student;
import com.lms.repository.StudentRepository;
import com.lms.repository.IssueRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class StudentService {

    private final StudentRepository studentRepo;
    private final IssueRepository issueRepo;

    public StudentService(StudentRepository studentRepo, IssueRepository issueRepo) {
        this.studentRepo = studentRepo;
        this.issueRepo = issueRepo;
    }

    public List<Student> getAllStudents() {
        return studentRepo.findAll();
    }

    public Student getStudentById(Long id) {
        return studentRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
    }

    public Student saveStudent(Student student) {

        if (studentRepo.existsByEmail(student.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        return studentRepo.save(student);
    }

    public Student updateStudent(Long id, Student updated) {
        Student student = getStudentById(id);

        student.setName(updated.getName());
        student.setEmail(updated.getEmail());

        return studentRepo.save(student);
    }

    public void deleteStudent(Long id) {

        if (issueRepo.countActiveIssuesByStudent(id) > 0) {
            throw new RuntimeException("Student has active issued books");
        }

        studentRepo.deleteById(id);
    }

    // 🔥 BUSINESS RULE: max 5 books
    public boolean canIssue(Long studentId) {
        return issueRepo.countActiveIssuesByStudent(studentId) < 5;
    }
}