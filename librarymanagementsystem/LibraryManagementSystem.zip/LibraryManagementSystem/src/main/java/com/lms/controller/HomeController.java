package com.lms.controller;

import com.lms.service.BookService;
import com.lms.service.IssueService;
import com.lms.service.StudentService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final BookService bookService;
    private final StudentService studentService;
    private final IssueService issueService;

    public HomeController(BookService b, StudentService s, IssueService i) {
        this.bookService = b;
        this.studentService = s;
        this.issueService = i;
    }

    @GetMapping("/")
    public String dashboard(Model model) {
        model.addAttribute("totalBooks", bookService.getAllBooks().size());
        model.addAttribute("students", studentService.getAllStudents().size());
        model.addAttribute("issues", issueService.getAllIssues().size());
        return "index";
    }
}