package com.lms.controller;

import com.lms.entity.Student;
import com.lms.service.StudentService;

import jakarta.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("students", service.getAllStudents());
        return "student-list";
    }

    @GetMapping("/add")
    public String form(Model model) {
        model.addAttribute("student", new Student());
        return "student-add";
    }

    @PostMapping("/add")
    public String save(@Valid @ModelAttribute Student student,
                       BindingResult result,
                       Model model,
                       RedirectAttributes ra) {

        if (result.hasErrors()) return "student-add";

        try {
            service.saveStudent(student);
            ra.addFlashAttribute("success", "Student added");
            return "redirect:/students";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "student-add";
        }
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id,
                         RedirectAttributes ra) {

        try {
            service.deleteStudent(id);
            ra.addFlashAttribute("success", "Student deleted");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/students";
    }
}