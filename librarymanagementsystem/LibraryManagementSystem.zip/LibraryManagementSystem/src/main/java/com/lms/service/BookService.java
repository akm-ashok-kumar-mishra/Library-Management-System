package com.lms.service;

import com.lms.exception.ResourceNotFoundException;
import com.lms.entity.Book;
import com.lms.repository.BookRepository;
import com.lms.repository.IssueRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class BookService {

    private final BookRepository bookRepo;
    private final IssueRepository issueRepo;

    public BookService(BookRepository bookRepo, IssueRepository issueRepo) {
        this.bookRepo = bookRepo;
        this.issueRepo = issueRepo;
    }

    public List<Book> getAllBooks() {
        return bookRepo.findAll();
    }

    public Book getBookById(Long id) {
        return bookRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
    }

    public Book saveBook(Book book) {
        if (bookRepo.existsByIsbn(book.getIsbn())) {
            throw new RuntimeException("ISBN already exists");
        }

        book.setAvailableCopies(book.getTotalCopies());
        return bookRepo.save(book);
    }

    public Book updateBook(Long id, Book updated) {
        Book book = getBookById(id);

        book.setTitle(updated.getTitle());
        book.setAuthor(updated.getAuthor());
        book.setIsbn(updated.getIsbn());

        int issued = Math.max(0, book.getTotalCopies() - book.getAvailableCopies());

        book.setTotalCopies(updated.getTotalCopies());
        book.setAvailableCopies(Math.max(0, updated.getTotalCopies() - issued));

        return bookRepo.save(book);
    }

    public void deleteBook(Long id) {
        Book book = getBookById(id);

        if (!issueRepo.findActiveIssuesByBook(id).isEmpty()) {
            throw new RuntimeException("Cannot delete book with active issues");
        }

        bookRepo.delete(book);
    }

    public List<Book> searchBooks(String keyword) {
        return bookRepo.searchBooks(keyword);
    }

    public List<Book> getAvailableBooks() {
        return bookRepo.findAvailableBooks();
    }

    // 🔥 Used internally
    public void decreaseAvailable(Long bookId) {
        Book book = getBookById(bookId);

        if (book.getAvailableCopies() <= 0) {
            throw new RuntimeException("No copies available");
        }

        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepo.save(book);
    }

    public void increaseAvailable(Long bookId) {
        Book book = getBookById(bookId);

        if (book.getAvailableCopies() < book.getTotalCopies()) {
            book.setAvailableCopies(book.getAvailableCopies() + 1);
            bookRepo.save(book);
        }
    }
}